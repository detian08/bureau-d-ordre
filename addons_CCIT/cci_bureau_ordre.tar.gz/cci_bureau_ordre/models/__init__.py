# -*- coding: utf-8 -*-

import note
import courriel
import courriel_entrant
import courriel_sortant

import mode_reception
import type_courriel
import degre
import importance
import urgence
import instruction







