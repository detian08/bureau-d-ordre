# -*- coding: utf-8 -*-

import res_partner_distance
import res_partner_request_distance
