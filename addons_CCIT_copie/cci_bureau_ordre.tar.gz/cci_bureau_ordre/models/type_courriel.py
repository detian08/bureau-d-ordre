# -*- coding: utf-8 -*-

from openerp import models, fields, api

class courriel_type(models.Model):
	_name = 'courriel.type'

	name =fields.Char(string="Type de courriel")


