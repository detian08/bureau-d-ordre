# -*- coding: utf-8 -*-
#import res_partner
#import res_partner_request
import distance_op_eco
