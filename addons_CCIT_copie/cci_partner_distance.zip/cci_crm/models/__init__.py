import sales_team
import crm_lead
import previous_action
import next_activity
import mail_mail
import calendar
import crm_phonecall
import res_partner_group
