# -*- coding: utf-8 -*-
import compagne_marketing
