# -*- coding: utf-8 -*-

import res_partner_distance
