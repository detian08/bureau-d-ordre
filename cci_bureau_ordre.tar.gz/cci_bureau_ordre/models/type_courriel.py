# -*- coding: utf-8 -*-

from openerp import models, fields, api

class courrier_type(models.Model):
	_name = 'courrier.type'

	name =fields.Char(string="Type de courriel")


