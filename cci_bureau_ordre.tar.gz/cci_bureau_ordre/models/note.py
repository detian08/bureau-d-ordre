# -*- coding: utf-8 -*-

from openerp import models, fields, api

class courrier_note(models.Model):
	_name = 'courrier.note'

	name =fields.Char(string="Note")
	responsable_id = fields.Many2one('res.partner', 'Responsable' , required=True)
	date_note = fields.Date(string='Date', default=fields.Date.today(), )
	note =fields.Text(string="Note",)


