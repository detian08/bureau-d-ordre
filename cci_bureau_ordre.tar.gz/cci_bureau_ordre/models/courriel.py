# -*- coding: utf-8 -*-

from openerp import models, fields, api

class cci_courrierl(models.Model):
	_name = 'cci.courrierl'
	_description="Les courriels"

	name = fields.Char(string="Réference",readonly=True, default=lambda self:self.env['ir.sequence'].get('RefCourriel'))
	note_id = fields.Many2one('courrier.note', 'Note' )
	type_id = fields.Many2one('courrier.type', 'Type de courriel')
	mode_id = fields.Many2one('courrier.mode', 'Mode de réception')
	degre_id = fields.Many2one('courrier.degre', 'Degrés de confidentialité')
	importance_id = fields.Many2one('courrier.important', 'Importance')
	urgent_id = fields.Many2one('courrier.urgence', 'Urgence')
	date_courriel = fields.Date(string='Date de réception', default=fields.Date.today(), )
	objet =fields.Text(string="Objet",)
	street =fields.Char(string="Rue",readonly=True)
	street2 =fields.Char(string="Street2",readonly=True)
	city =fields.Char(string="Ville",readonly=True)
	zip =fields.Char(string="Code postale",readonly=True, size=24, change_default=True)
	country_id = fields.Many2one('res.country', 'Pays' , ondelete='restrict')
	website =fields.Char(string="Site Web",readonly=True, help="Website of Partner or Company")
	state_id = fields.Many2one('res.country.state', 'State' , ondelete='restrict')
	name =fields.Char(string="Nom",readonly=True)
	function =fields.Char(string="Poste occupé",readonly=True)
	phone =fields.Char(string="Tél.",readonly=True)
	email =fields.Char(string="Courriel.",readonly=True)
	is_company =fields.Boolean(help="Check if the contact is a company, otherwise it is a person")
	title = fields.Many2one('res.partner.title', 'Civilité')
	dept_id = fields.Many2one('crm.case.section', 'Département' , ondelete='restrict')

 	#liste_dest_ids = fields.One2many(comodel_name="res.partner", string='Liste de destinataire', inverse_name="operator_id")



	state = fields.Selection([
	('draft', "Brouillon"),
	('to_soumpre', "Soumis au président"),
	('to_soumdg', "soumis à la DG"),
	], default='draft', string="État")

	@api.multi
	def draft(self):
		print 'hello brouillon'
		self.state = 'draft'

	@api.multi
	def to_soumpre(self):
		print 'hello soumpre'
		self.state = 'to_soumpre'

	@api.multi
	def to_soumdg(self):
		print 'hello soumdg'
		self.state = 'to_soumdg'





  




        


