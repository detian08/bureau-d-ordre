# -*- coding: utf-8 -*-

from openerp import models, fields, api

class cci_courriel_entrant(models.Model):
	_name = 'cci.courriel.entrant'
	_description="Les courriels entrants"

	reference = fields.Char(string="Réference",readonly=True, default=lambda self:self.env['ir.sequence'].get('RefCourriel'))
	state = fields.Selection([
	('draft', "Brouillon"),
	('to_soumpre', "Soumis au président"),
	('to_soumdg', "soumis à la DG"),
	], default='draft', string="État")
