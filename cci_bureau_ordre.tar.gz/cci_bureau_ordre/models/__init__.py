# -*- coding: utf-8 -*-

import note
import courriel
import mode_reception
import type_courriel
import degre
import importance
import urgence







