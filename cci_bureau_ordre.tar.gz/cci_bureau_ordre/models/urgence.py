# -*- coding: utf-8 -*-

from openerp import models, fields, api

class courrier_urgence(models.Model):
	_name = 'courrier.urgence'

	name =fields.Char(string="urgence")


