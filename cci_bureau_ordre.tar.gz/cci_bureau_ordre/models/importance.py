# -*- coding: utf-8 -*-

from openerp import models, fields, api

class courrier_important(models.Model):
	_name = 'courrier.important'

	name =fields.Char(string="Importance")


